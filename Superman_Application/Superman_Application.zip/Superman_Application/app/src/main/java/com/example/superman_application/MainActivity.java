package com.example.superman_application;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.example.superman_application.Controller.IBrowseController;

import com.example.superman_application.DTO.IssueDTO;
import com.example.superman_application.RetrofitApi.APIClient;
import com.example.superman_application.TokenHandling.Token;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity {
    private TextView textView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.viewComics);
        IBrowseController iBrowseController = APIClient.createService(IBrowseController.class, Token.getInstance());

        Call<List<IssueDTO>> call = iBrowseController.getComics();

        call.enqueue(new Callback<List<IssueDTO>>() {
            @Override
            public void onResponse(Call<List<IssueDTO>> call, Response<List<IssueDTO>> response) {

                List<IssueDTO> browseDTOS = response.body();
                for (IssueDTO browseDTO : browseDTOS) {
                    String content = "";
                    content += "Title " + browseDTO.getTitle() + "\n";
                    content += "Description " + browseDTO.getDescription() + "\n";
                    content += "SeriesNumber " + browseDTO.getSeriesNumber() + "\n";




                    content += "Publisher " + browseDTO.getPublisher() + "\n";
                    content += "Cover Image " + browseDTO.getCoverImagePath() + "\n\n";
                    textView.append(content);

//                    System.out.println("Title "+browseDTO.getIssueTitle());
//                    System.out.println("Description " + browseDTO.getDescription());
//                    System.out.println("Condition " + browseDTO.getCondition());
//                    System.out.println("Available Quantity " + browseDTO.getAvailableQuantity());
//                    System.out.println("Reference ID "+ browseDTO.getStockReferenceId());
//                    System.out.println("Series Number "+browseDTO.getSeriesNumber());
//                    System.out.println("Price "+browseDTO.getPrice());
//                    System.out.println("Publisher "+ browseDTO.getPublisher());
//                    System.out.println("Cover Image " +browseDTO.getCoverImage());
                }
            }

            @Override
            public void onFailure(Call<List<IssueDTO>> call, Throwable t) {
                textView.setText(t.getMessage());
            }
        });


    }
}
