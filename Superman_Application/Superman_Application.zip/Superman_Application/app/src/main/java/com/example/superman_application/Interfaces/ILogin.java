package com.example.superman_application.Interfaces;

public interface ILogin {
    void LoginUser();
}
