package com.example.superman_application.Presenter;

import com.example.superman_application.DTO.LoginDTO;

public interface ILoginPresenter {
    void loginUser(LoginDTO loginDTO);
}
