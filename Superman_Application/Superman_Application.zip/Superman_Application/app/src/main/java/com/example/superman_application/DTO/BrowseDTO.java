package com.example.superman_application.DTO;

import java.util.List;

public class BrowseDTO {

    private List<IssueDTO> content;


    public List<IssueDTO> getStockDTOlist() {
        return content;
    }



}
